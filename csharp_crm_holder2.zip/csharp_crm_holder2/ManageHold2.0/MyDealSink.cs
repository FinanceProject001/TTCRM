﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaQuotes.MT5CommonAPI;
//using System.Data.SQLite;
using BalanceExample.NET;
using System.Collections;
using System.IO;
using aliManageGendan;
using System.Xml.Linq;
using System.Threading;
using ManageHolderService;
using AliLib4net;

namespace Meta5API.NET
{
    class MyDealSink: CIMTDealSink
    {
        

        private CManager manage;
        DealModal dealModal = null;
        public static ulong last_ticket = 0;
        private AlixLog log;

        public  MyDealSink( CManager manage)
        {
            this.manage = manage;
            dealModal = new DealModal(manage);
            log = new AlixLog();

            RegisterSink();
        }



        //SQLiteConnection m_dbConnection;
        public override void OnDealAdd(CIMTDeal deal)
        {


            


            Util.Info(deal.Action() + "  " + deal.Entry());
            last_ticket = deal.Deal();
            //aaaaa(deal.PositionID(), deal.Login(),deal.Entry(),deal.Action(), deal.Symbol(), deal.Volume(), deal.Price(),deal.VolumeClosed());
            if (true)
            {
                

                dealModal.input_queue(deal.Action(), deal.Entry(), deal.Comment(), deal.Login(), deal.PositionID(), deal.Volume(), deal.VolumeClosed()
                    , deal.Symbol(), deal.Deal(), deal.Price(), deal.Time(), deal.Commission(), deal.Profit(), deal.Storage() , deal.ExternalID());
                return;
            }




            /*




            if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_IN && (uint)CIMTDeal.EnDealAction.DEAL_BALANCE == deal.Action()) {
                string post = manage.HttpPost(manage.get_crm_host() + "/index.php/index/meta5/inject_balance", "value=" +deal.Login()+"_"+ manage.getBalanceBylogin(deal.Login()));
                Util.Info(post);



            }else if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_IN || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_INOUT)
            {


                string list = "[{";
                list += "\"login\":\"" + deal.Login() + "\",";
                list += "\"deal\":\"" + deal.Deal() + "\",";
                list += "\"symbol\":\"" + deal.Symbol() + "\",";
                list += "\"open_price\":\"" + deal.Price() + "\",";
                list += "\"open_time\":\"" + deal.Time() + "\",";
                list += "\"direct\":\"" + deal.Action() + "\",";
                list += "\"ticket\":\"" + deal.PositionID() + "\",";
                list += "\"commission\":\"" + deal.Commission() + "\",";
                list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";

                list += "\"comment\":\"\"";
                list += ",\"balance\":\"" + manage.getBalanceBylogin(deal.Login()) + "\"";
                list += "}]";
                
                string json = "{\"list\":" + list + "}";
                Util.Info(json);
                string post = manage.HttpPost(manage.get_crm_host() + "/index.php/index/meta5/inject_open", "value=" + json);
                Util.Info(post);


                //出场
            }
            else if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT_BY)
            {

                string list = "[{";
                //list += "\"login\":\"" + deal.Login() + "\",";
                list += "\"deal\":\"" + deal.Deal() + "\",";
                //list += "\"symbol\":\"" + deal.Symbol() + "\",";
                list += "\"close_price\":\"" + deal.Price() + "\",";
                list += "\"close_time\":\"" + deal.Time() + "\",";

                list += "\"ticket\":\"" + deal.PositionID() + "\",";
                list += "\"commission\":\"" + deal.Commission() + "\",";
                list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";
                list += "\"lots_closed\":\"" + (deal.VolumeClosed() / 100) + "\",";
                list += "\"swap\":\"" + deal.Storage() + "\",";
                list += "\"profit\":\"" + deal.Profit() + "\"";
                list += ",\"balance\":\"" + manage.getBalanceBylogin(deal.Login()) + "\"";


                //list += "\"comment\":\"" + deal.Comment() + "\"";

                list += "}]";

                string json = "{\"list\":" + list + "}";


                Util.Info(json);
                string post = manage.HttpPost(manage.get_crm_host() + "/index.php/index/meta5/inject_close", "value=" + json);
                Util.Info(post);
            }

            Util.Info("--------------------------------");

            File.WriteAllText("end_ticket", deal.Deal() + "");
            */

        }
        public override void OnDealClean(ulong login)
        {
            Util.Info(login+ "OnDealClean");
        }
        public override void OnDealDelete(CIMTDeal deal)
        {
            Util.Info(deal.Login() + "OnDealDelete");
        }
        public override void OnDealPerform(CIMTDeal deal, CIMTAccount account, CIMTPosition position)
        {
            Util.Info(deal.Login() + "OnDealPerform");
        }
        public override void OnDealSync()
        {
            Util.Info("OnDealSync");
        }
        public override void OnDealUpdate(CIMTDeal deal)
        {
            Util.Info(deal.Login() + "OnDealUpdate");
        }



    }
}
