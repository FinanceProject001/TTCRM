﻿using aliManageGendan;
using BalanceExample.NET;
using ManageHolderService;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Topshelf;
using static System.Net.Mime.MediaTypeNames;

namespace ManageHold2._0
{
    class Program
    {








        static void Main(string[] args)
        {
            Hashtable mArgs = Util.loadXml();
            if (Util.isdebug)
            {
                
                new QuotesService().Start(mArgs);
                while (true)
                {

                    Thread.Sleep(10000);
                }

            }






            // 配置和运行宿主服务
            HostFactory.Run(x =>
            {
                // 指定服务类型。这里设置为 CacheService
                x.Service<QuotesService>(s =>
                {
                    // 通过 new CacheService() 构建一个服务实例
                    s.ConstructUsing(name => new QuotesService());
                    // 当服务启动后执行什么
                    s.WhenStarted(tc => tc.Start(mArgs));
                    // 当服务停止后执行什么
                    s.WhenStopped(tc => tc.Stop());
                });
                // 服务用本地系统账号来运行
                x.RunAsLocalSystem();
                // 服务描述信息
                x.SetDescription("TTCRM-ManageHold2.0服务");
                TimeSpan t = new TimeSpan(0,0,30);
                x.SetStartTimeout(t);
                x.SetStartTimeout(t);
                x.StartAutomaticallyDelayed();
                // 服务显示名称
                x.SetDisplayName("AAATTCRM["+ mArgs["port"].ToString()+"]("+ mArgs["name"].ToString()+")");
                // 服务名称
                x.SetServiceName("AAATTCRM[" + mArgs["port"].ToString() + "](" + mArgs["name"].ToString() + ")");
            });




        }
    }


    public class QuotesService
    {
        //public static bool debug = false;
        Thread thread;






        public QuotesService()
        {

        }
        public void Start(Hashtable mArgs)
        {

             thread = new Thread(run);
            thread.IsBackground = true;
            thread.Start();








        }
        public void Stop() {
            Util.service_run = false;
            Util.Info("-----stop-----");
            thread.Abort();
            //System.Environment.Exit(1);





        }




        public void run() {




            //while (true)
            //{
            //    MongoUtil.getconnection();
            //    bool x = MongoUtil.find_count("ali", "test", "36");
            //    Console.WriteLine(x);
            //    Thread.Sleep(100);
            //}

            //MongoUtil.set_last_ticket(100 + "");
            //MongoUtil.set_key_value("last_dealfasdf","fasdfsad");

            //Console.WriteLine(MongoUtil.get_value_by_key("last_deal"));
            //if (true) return;

            CManager c = new CManager();
            bool login_flag = false;
            while (true)
            {
                Hashtable mArgs = Util.loadXml();
                Console.WriteLine("准备登录");
                c.Initialize();

                c.set_crm_host(mArgs["crm_host"].ToString());
                c.set_port(int.Parse(mArgs["port"].ToString()));
                login_flag = c.Login((string)mArgs["manage_host"], ulong.Parse(mArgs["manage_user"].ToString()), Util.Decode((string)mArgs["manage_psd"]));

                Console.WriteLine(login_flag+"-"+ mArgs["manage_user"].ToString());
                
                if (login_flag)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("登录失败，300秒后重试");
                    Thread.Sleep(300000);
                }
            }





            c.get_price();
            //c.fk();
            c.hello();
            //for(ulong i = 0; i < 100; i++)
            //{
            //    c.go(17074+i);
            //}
            






        }



    }

}
