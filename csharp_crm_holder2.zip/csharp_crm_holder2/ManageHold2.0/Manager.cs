﻿//+------------------------------------------------------------------+
//|                        MetaTrader 5 API Manager for .NET Example |
//|                   Copyright 2001-2016, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
namespace BalanceExample.NET
{
    using MetaQuotes.MT5CommonAPI;
    using MetaQuotes.MT5ManagerAPI;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Threading;
    using System.Xml.Linq;
    using System.Collections;
    using System.IO;
    using System.Security.Cryptography;
    using System.Net.Mail;
    using System.Linq;

    using System.Text;
    using System.Net;
    using Newtonsoft.Json;
    using AliLib4net;
    using Meta5API.NET;
    using ManageHolderService;
    using System.Net.Sockets;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using WebSocketDemo;
    using ManageHold2._0;
    using static System.Net.Mime.MediaTypeNames;
    using System.Web;
    using MetaQuotes.MT5WebAPI.Common;


    //+------------------------------------------------------------------+
    //| Manager                                                          |
    //+------------------------------------------------------------------+
    class CManager : IDisposable
    {

        List<ulong> users;
        AlixLog log;
        private string crm_host = "";
        WebSocketManager ws_manage;

        //--- connect timeout in milliseconds
        uint MT5_CONNECT_TIMEOUT = 30000;
        //---
        CIMTManagerAPI m_manager = null;
        CIMTDealArray m_deal_array = null;
        CIMTUser m_user = null;
        CIMTAccount m_account = null;
        //+------------------------------------------------------------------+
        //|                                                                  |
        //+------------------------------------------------------------------+
        public CManager()
        {
            users = new List<ulong>();
            log = new AlixLog();
        }
        //+------------------------------------------------------------------+
        //|                                                                  |
        //+------------------------------------------------------------------+
        public void Dispose()
        {
            Shutdown();
        }
        //+------------------------------------------------------------------+
        //| Initialize library                                               |
        //+------------------------------------------------------------------+
        public bool Initialize()
        {
            string message = string.Empty;
            MTRetCode res = MTRetCode.MT_RET_OK_NONE;
            //--- loading manager API
            if ((res = SMTManagerAPIFactory.Initialize(null)) != MTRetCode.MT_RET_OK)
            {
                message = string.Format("Loading manager API failed ({0})", res);
                return (false);
            }
            //--- creating manager interface
            m_manager = SMTManagerAPIFactory.CreateManager(SMTManagerAPIFactory.ManagerAPIVersion, out res);
            if ((res != MTRetCode.MT_RET_OK) || (m_manager == null))
            {
                SMTManagerAPIFactory.Shutdown();
                message = string.Format("Creating manager interface failed ({0})", (res == MTRetCode.MT_RET_OK ? "Managed API is null" : res.ToString()));
                return (false);
            }
            //--- create deal array
            if ((m_deal_array = m_manager.DealCreateArray()) == null)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "DealCreateArray fail");
                return (false);
            }
            //--- create user interface
            if ((m_user = m_manager.UserCreate()) == null)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "UserCreate fail");
                return (false);
            }
            //--- create account interface
            if ((m_account = m_manager.UserCreateAccount()) == null)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "UserCreateAccount fail");
                return (false);
            }
            //--- all right
            return (true);
        }
        //+------------------------------------------------------------------+
        //| Login                                                            |
        //+------------------------------------------------------------------+

        public bool Login(string server, UInt64 login, string password)
        {
            //--- connect
            MTRetCode res = m_manager.Connect(server, login, password, null, CIMTManagerAPI.EnPumpModes.PUMP_MODE_FULL, MT5_CONNECT_TIMEOUT);
            if (res != MTRetCode.MT_RET_OK)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "Connection failed ({0})", res);

                Util.Info("登录失败");
                return (false);
            }

            mArgs = Util.loadXml();
            manage_sink = new MyManageSink(this);
            m_manager.Subscribe(manage_sink);
            sink = new MyDealSink(this);
            m_manager.DealSubscribe(sink);
            tick_sink = new MyTickSink(this);
            m_manager.TickSubscribe(tick_sink);



            Util.Info("登录成功");

            return (true);
        }
        //+------------------------------------------------------------------+
        //|                                                                  |
        //+------------------------------------------------------------------+
        public void Logout()
        {
            //--- disconnect manager
            if (m_manager != null)
                m_manager.Disconnect();
        }
        //+------------------------------------------------------------------+
        //| Shutdown                                                         |
        //+------------------------------------------------------------------+
        public void Shutdown()
        {
            if (m_deal_array != null)
            {
                m_deal_array.Dispose();
                m_deal_array = null;
            }
            if (m_manager != null)
            {
                m_manager.Dispose();
                m_manager = null;
            }
            if (m_user != null)
            {
                m_user.Dispose();
                m_user = null;
            }
            if (m_account != null)
            {
                m_account.Dispose();
                m_account = null;
            }
            SMTManagerAPIFactory.Shutdown();
        }
        //+------------------------------------------------------------------+
        //| Get array of dealer balance operation                            |
        //+------------------------------------------------------------------+
        public bool GetUserDeal(out CIMTDealArray deals, UInt64 login, DateTime time_from, DateTime time_to)
        {
            deals = null;
            //--- request array
            MTRetCode res = m_manager.DealRequest(login, SMTTime.FromDateTime(time_from), SMTTime.FromDateTime(time_to), m_deal_array);
            if (res != MTRetCode.MT_RET_OK)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "DealRequest fail({0})", res);



                return (false);
            }
            //---
            deals = m_deal_array;
            return (true);
        }
        //+------------------------------------------------------------------+
        //| Get user info string                                             |
        //+------------------------------------------------------------------+
        public bool GetUserInfo(UInt64 login, out string str)
        {
            str = string.Empty;
            //--- request user from server
            m_user.Clear();
            MTRetCode res = m_manager.UserRequest(login, m_user);
            if (res != MTRetCode.MT_RET_OK)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "UserRequest error ({0})", res);
                return (false);
            }
            //--- format string
            str = string.Format("{0},{1},{2},1:{3}", m_user.Name(), m_user.Login(), m_user.Group(), m_user.Leverage());
            //---
            return (true);
        }
        //+------------------------------------------------------------------+
        //| Get user info string                                             |
        //+------------------------------------------------------------------+
        public bool GetAccountInfo(UInt64 login, out string str)
        {
            str = string.Empty;
            //--- request account from server
            m_account.Clear();
            MTRetCode res = m_manager.UserAccountRequest(login, m_account);
            if (res != MTRetCode.MT_RET_OK)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "UserAccountRequest error ({0})", res);
                return (false);
            }
            //--- format string
            str = string.Format("Balance: {0} Equity: {1} Margin: {2} Free: {3}", m_account.Balance(), m_account.Equity(), m_account.Margin(), m_account.MarginFree());
            //---
            return (true);
        }
        //+------------------------------------------------------------------+
        //| Dealer operation                                                 |
        //+------------------------------------------------------------------+
        public bool DealerBalance(UInt64 login, double amount, uint type, string comment, bool deposit)
        {
            UInt64 deal_id = 0;
            //--- dealer operation
            MTRetCode res = m_manager.DealerBalance(login, (deposit ? amount : -amount), type, comment, out deal_id);
            if (res != MTRetCode.MT_RET_REQUEST_DONE)
            {
                m_manager.LoggerOut(EnMTLogCode.MTLogErr, "DealerBalance failed ({0})", res);
                return (false);
            }
            //---
            return (true);
        }



        
        MyDealSink sink = null;
        MyManageSink manage_sink = null;
        //MyDealSinkx sinkx = null;
        MyTickSink tick_sink = null;




        public double getBalanceBylogin(ulong login)
        {
            CIMTAccount account = m_manager.UserCreateAccount();
            m_manager.UserAccountGet(login, account);

            return account.Balance();
        }


        MyOpenSink sink_open = null;




        public MTRetCode open(ulong login, String symbol, CIMTOrder.EnOrderType direct, ulong lots, String comments)
        {
            //Util.Info("--------open-------------");
            if (sink_open == null)
                sink_open = new MyOpenSink(this);
            uint id = 0;
            CIMTRequest t = m_manager.RequestCreate();
            //CIMTConfirm con = m_manager.DealerConfirmCreate();


            MTTickShort ms = this.get_value(symbol);
            double price = ms.bid;
            if (direct == 0)
            {
                price = ms.ask + 0.00001;
            }


            t.Clear();
            t.Login(login);
            t.Action(CIMTRequest.EnTradeActions.TA_DEALER_POS_EXECUTE);
            t.Type(direct);
            t.Volume(lots);
            t.Symbol(symbol);
            t.PriceOrder(price);
            t.TypeFill(CIMTOrder.EnOrderFilling.ORDER_FILL_RETURN);



            t.Comment(comments);

            MTRetCode cs = m_manager.DealerSend(t, sink_open, out id);

            //sink.OnDealerResult(con);
            if (cs == MTRetCode.MT_RET_OK)
            {
                //Util.Info("-----------------"+cs);

            }
            t.Clear();
            return cs;


        }


        MyCloseSink sink_close = null;

        public MTRetCode close(ulong login, ulong lots, ulong ticket, CIMTOrder.EnOrderType type, String symbol)
        {



            if (sink_close == null)
                sink_close = new MyCloseSink(this);
            uint id = 0;
            CIMTRequest t = m_manager.RequestCreate();
            //Util.Info(t);
            //CIMTConfirm con = m_manager.DealerConfirmCreate();

            MTTickShort ms = this.get_value(symbol);
            double price = ms.bid;

            if (type == 0)
            {
                price = ms.ask + 0.00001;
            }



            t.Clear();
            t.Login(login);
            t.Action(CIMTRequest.EnTradeActions.TA_DEALER_POS_EXECUTE);
            t.Position(ticket);
            t.Symbol(symbol);
            t.Type(type);
            t.Volume(lots);
            t.PriceOrder(price);
            t.TypeFill(CIMTOrder.EnOrderFilling.ORDER_FILL_FIRST);

            t.Flags(CIMTRequest.EnTradeActionFlags.TA_FLAG_CLOSE | CIMTRequest.EnTradeActionFlags.TA_FLAG_MARKET);



            MTRetCode cs = m_manager.DealerSend(t, sink_close, out id);

            //Util.Info("MTRetCode=" + cs);

            if (cs == MTRetCode.MT_RET_OK)
            {


            }
            t.Clear();
            return cs;



        }




        

        public static string Encode(string data)
        {
            string KEY_64 = "alicrm88";
            string IV_64 = "alicrm88";
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(KEY_64);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(IV_64);
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            int i = cryptoProvider.KeySize;
            MemoryStream ms = new MemoryStream();
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateEncryptor(byKey, byIV), CryptoStreamMode.Write);
            StreamWriter sw = new StreamWriter(cst);
            sw.Write(data);
            sw.Flush();
            cst.FlushFinalBlock();
            sw.Flush();
            return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
        }

        public static string Decode(string data)
        {
            string KEY_64 = "alicrm88";
            string IV_64 = "alicrm88";
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(KEY_64);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(IV_64);
            byte[] byEnc;
            try
            {
                byEnc = Convert.FromBase64String(data);
            }
            catch
            {
                return null;
            }
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream(byEnc);
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateDecryptor(byKey, byIV), CryptoStreamMode.Read);
            StreamReader sr = new StreamReader(cst);
            return sr.ReadToEnd();
        }


        public void deal_restartaaaa()
        {

            if (sink != null)
            {

                m_manager.DealUnsubscribe(sink);
                m_manager.DealSubscribe(sink);

                m_manager.Unsubscribe(manage_sink);
                m_manager.Subscribe(manage_sink);
            }




        }


        public MTTickShort get_value(String symbol)
        {
            // var utcNow = DateTime.UtcNow;
            // var timeSpan = utcNow - new DateTime(1970, 1, 1, 0, 0, 0);
            // long tick =  (long)(timeSpan.TotalSeconds);
            MTTickShort tc = new MTTickShort();
            MTRetCode code = m_manager.TickLast(symbol, out tc);
            return tc;
        }









        public void sink_restart()
        {
            m_manager.DealUnsubscribe(sink);
            m_manager.TickUnsubscribe(tick_sink);
            m_manager.Unsubscribe(manage_sink);
            MTRetCode code;
            code = m_manager.DealSubscribe(sink);

            //Util.Info("deal-" + code);

            code = m_manager.TickSubscribe(tick_sink);
           // Util.Info("deal-" + code);

            code = m_manager.Subscribe(manage_sink);
            //Util.Info("deal-" + code);

        }
        public void inject_point_value()
        {
            String inject_point_value = HttpPost(crm_host + "/index.php/setting/symbol/inject_profit_per_point", "");
            Util.Info("inject_point_value=>" + inject_point_value);
        }
        Hashtable mArgs;
        public void hello()
        {

            int count = 0;

             
            

            socket_tr();


            //open(864063,"EURUSD", CIMTOrder.EnOrderType.OP_SELL,200,"FFFFF");
            //close(864063,200, 143631, CIMTOrder.EnOrderType.OP_BUY);

            new Task(() => {

                while (true)
                {
                    

                    if (count % 10 == 0 && Util.service_run)
                    {
                        this.sink_restart();
                        //Util.Info(args["times"]);
                        //report();
                        forceUpload_mongo();
                    }

                    if (count % 1000 == 0 && Util.service_run)
                    {
                        this.inject_point_value();
                    }

                    
                    count++;







                    Thread.Sleep(3000);
                    //sink.check();
                    //sink.check2(this);
                    
                }


            }).Start();



           





        }
        int woshou_count = 0;

        public void forceUploadxxx()
        {
            string aaa = HttpPost(crm_host + "/index.php/index/Meta5/woshou", "value=100");

            if (woshou_count >= 5 && aaa != "true")
            {
                System.Diagnostics.Process p = new System.Diagnostics.Process();
                p.StartInfo.FileName = System.Environment.CurrentDirectory + "\\ManageHolderService.exe";
                p.StartInfo.UseShellExecute = true;    //是否使用操作系统shell启动
                p.StartInfo.RedirectStandardInput = false;//接受来自调用程序的输入信息
                p.StartInfo.RedirectStandardOutput = false;//由调用程序获取输出信息
                p.StartInfo.RedirectStandardError = false;//重定向标准错误输出
                p.StartInfo.CreateNoWindow = false;//不显示程序窗口
                p.Start();//启动程序

                Process.GetCurrentProcess().Kill();
            }


            woshou_count++;

            /*
            if (!File.Exists("begin_ticket"))
            {
                Util.Info("缺少begin_ticket文件");
                return;
            }
            if (!File.Exists("end_ticket"))
            {
                Util.Info("缺少end_ticket文件");
                return;
            }
            */
            //string b = HttpPost(crm_host + "/index.php/setting/global_setting/get_last_ticket", "");
            //if (b == "0")
            //{
            //    if (MyDealSink.last_ticket != 0)
            //    {
            //        string ccc = HttpPost(crm_host + "/index.php/setting/global_setting/set_last_ticket?ticket=" + MyDealSink.last_ticket, "");

            //        return;
            //    }

            //}
            string b = MongoUtil.get_value_by_key("last_deal");
            if (b == "") { return; }

            ulong begin = ulong.Parse(b);
            ulong end = MyDealSink.last_ticket;





            if (begin == end) return;

            CIMTDealArray deals = m_manager.DealCreateArray();
            CIMTDeal deal = m_manager.DealCreate();
            string in_list = "[";
            string out_list = "[";



            ulong endx = (end < begin + 150 ? end : begin + 150);
            Util.Info(begin + "  " + end + "  " + endx);
            for (ulong i = begin; i <= endx; i++)
            {

                m_manager.DealRequest(i, deal);
                if (deal.Login() == 0 || deal.Volume() == 0) continue;
                //if (deal.Login() != 816222) continue;
                //Util.Info(deal.Login() + "----------------" + deal.Commission() + "--------------------" + deal.Profit());

                if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_IN || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_INOUT)
                {
                    in_list += "{";

                    in_list += "\"login\":\"" + deal.Login() + "\",";
                    in_list += "\"deal\":\"" + deal.Deal() + "\",";
                    in_list += "\"symbol\":\"" + deal.Symbol() + "\",";
                    in_list += "\"open_price\":\"" + deal.Price() + "\",";
                    in_list += "\"open_time\":\"" + deal.Time() + "\",";
                    in_list += "\"direct\":\"" + deal.Action() + "\",";
                    in_list += "\"ticket\":\"" + deal.PositionID() + "\",";
                    in_list += "\"commission\":\"" + deal.Commission() + "\",";
                    in_list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";
                    in_list += "\"lp_ticket\":\"" + deal.ExternalID() + "\",";

                    in_list += "\"comment\":\"\"";

                    in_list += "},";
                }
                else if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT_BY)
                {
                    out_list += "{";

                    out_list += "\"login\":\"" + deal.Login() + "\",";
                    out_list += "\"deal\":\"" + deal.Deal() + "\",";
                    out_list += "\"symbol\":\"" + deal.Symbol() + "\",";
                    out_list += "\"close_price\":\"" + deal.Price() + "\",";
                    out_list += "\"close_time\":\"" + deal.Time() + "\",";

                    out_list += "\"ticket\":\"" + deal.PositionID() + "\",";
                    out_list += "\"commission\":\"" + deal.Commission() + "\",";
                    out_list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";
                    out_list += "\"lots_closed\":\"" + (deal.VolumeClosed() / 100) + "\",";
                    out_list += "\"swap\":\"" + deal.Storage() + "\",";
                    out_list += "\"profit\":\"" + deal.Profit() + "\"";





                    out_list += "},";
                }

            }
            if (in_list.Contains("},"))
            {
                in_list = in_list.Substring(0, in_list.Length - 1);
            }

            if (out_list.Contains("},"))
            {
                out_list = out_list.Substring(0, out_list.Length - 1);
            }

            in_list += "]";
            out_list += "]";
            string json_in = "{\"list\":" + in_list + "}";
            string json_out = "{\"list\":" + out_list + "}";


            //Util.Info(json_in);
            //Util.Info(json_out);
            string postin = HttpPost(crm_host + "/index.php/index/Meta5/inject_open", "value=" + json_in);
            Util.Info("force->" + postin);
            string postout = HttpPost(crm_host + "/index.php/index/Meta5/inject_close", "value=" + json_out);
            Util.Info("force->" + postout);
            if (postin.Contains("ok") && postout.Contains("ok"))
            {
                //必须是 明确返回 成功方可 更改
                //File.WriteAllText("begin_ticket", end + "");
                if (endx != 0)
                {
                    //string last_ticket = HttpPost(crm_host + "/index.php/setting/global_setting/set_last_ticket?ticket=" + endx, "");
                    MongoUtil.set_key_value("last_deal", endx+"");
                    
                    
                }



            }










        }

        public void forceUpload_mongo()
        {
            


            string b = MongoUtil.get_value_by_key("last_deal");
            string c = MongoUtil.get_value_by_key("newest_deal");
            if (c != "" && b == "")
            {
                Util.Info("last_deal is empty");
                MongoUtil.set_key_value("last_deal", c);
            }

            if (c == "" || b == "") { return; }
            

            ulong begin = ulong.Parse(b);
            ulong end = ulong.Parse(c);

            if (begin == end) return;

            CIMTDealArray deals = m_manager.DealCreateArray();
            CIMTDeal deal = m_manager.DealCreate();


            Util.Info("开始强制同步");

            ulong endx = (end < begin + 150 ? end : begin + 150);
            Util.Info(begin + "  " + end + "  " + endx);
            int mycount = 0;
            Util.Info("开始循环");
            MTRetCode code;
            for (ulong i = begin; i <= endx; i++)
            {
                string in_list = "[";
                string out_list = "[";
                mycount = 0;
                Util.Info("index="+i);
                code  =  m_manager.DealRequest(i, deal);
                if (code == MTRetCode.MT_RET_ERR_NOTFOUND)
                {
                    MongoUtil.set_key_value("last_deal", i + "");
                    Util.Info(i+" - MT_RET_ERR_NOTFOUND");
                    continue;
                }
                if (code != MTRetCode.MT_RET_OK)
                {
                    Util.Info("发生错误---"+code+" "+i);
                    break;
                }
                
                //如果已经标记可以了

                //直接返回
                if (MongoUtil.get_status_by_deal(deal.Deal() + "") == 1) {
                    //标记last_ticket
                    MongoUtil.set_key_value("last_deal", i + "");
                    Util.Info(i + " - 在订单里显示已经存在了");
                    continue;
                }







                //if (deal.Login() != 816222) continue;
                //Util.Info(deal.Login() + "----------------" + deal.Commission() + "--------------------" + deal.Profit());

                if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_IN || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_INOUT)
                {
                    in_list += "{";
                    mycount++;
                    in_list += "\"login\":\"" + deal.Login() + "\",";
                    in_list += "\"deal\":\"" + deal.Deal() + "\",";
                    in_list += "\"symbol\":\"" + deal.Symbol() + "\",";
                    in_list += "\"open_price\":\"" + deal.Price() + "\",";
                    in_list += "\"open_time\":\"" + deal.Time() + "\",";
                    in_list += "\"direct\":\"" + deal.Action() + "\",";
                    in_list += "\"ticket\":\"" + deal.PositionID() + "\",";
                    in_list += "\"commission\":\"" + deal.Commission() + "\",";
                    in_list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";
                    in_list += "\"lp_ticket\":\"" + deal.ExternalID() + "\",";

                    in_list += "\"comment\":\"\"";

                    in_list += "},";
                }
                else if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT_BY)
                {
                    out_list += "{";
                    mycount++;
                    out_list += "\"login\":\"" + deal.Login() + "\",";
                    out_list += "\"deal\":\"" + deal.Deal() + "\",";
                    out_list += "\"symbol\":\"" + deal.Symbol() + "\",";
                    out_list += "\"close_price\":\"" + deal.Price() + "\",";
                    out_list += "\"close_time\":\"" + deal.Time() + "\",";

                    out_list += "\"ticket\":\"" + deal.PositionID() + "\",";
                    out_list += "\"commission\":\"" + deal.Commission() + "\",";
                    out_list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";
                    out_list += "\"lots_closed\":\"" + (deal.VolumeClosed() / 100) + "\",";
                    out_list += "\"swap\":\"" + deal.Storage() + "\",";
                    out_list += "\"profit\":\"" + deal.Profit() + "\"";





                    out_list += "},";
                }

                if (in_list.Contains("},"))
                {
                    in_list = in_list.Substring(0, in_list.Length - 1);
                }

                if (out_list.Contains("},"))
                {
                    out_list = out_list.Substring(0, out_list.Length - 1);
                }
                in_list += "]";
                out_list += "]";
                string json_in = "{\"list\":" + in_list + "}";
                string json_out = "{\"list\":" + out_list + "}";

                //json_in = json_in.Replace("[]]}", "[]}");
                //json_out = json_out.Replace("[]]}", "[]}");



                if (mycount == 0)
                {
                    if (endx != 0)
                    {
                        MongoUtil.set_key_value("last_deal", i + "");
                        continue;
                    }
                }
                string postin;
                string postout;

                postin = HttpPost(crm_host + "/index.php/index/Meta5/inject_open", "value=" + json_in);
                Util.Info("force->" + postin);
                

                postout = HttpPost(crm_host + "/index.php/index/Meta5/inject_close", "value=" + json_out);
                Util.Info("force->" + postout);
                



                if (postin.Contains("ok") && postout.Contains("ok"))
                {
                    //必须是 明确返回 成功方可 更改
                    //File.WriteAllText("begin_ticket", end + "");
                    if (i != 0)
                    {
                        //string last_ticket = HttpPost(crm_host + "/index.php/setting/global_setting/set_last_ticket?ticket=" + endx, "");
                        MongoUtil.set_key_value("last_deal", i + "");

                    }



                }
                else
                {
                    break;
                }




            }
            

            



            










        }



        public void get_all_symbol000(MyTickSink tick)
        {


            CIMTConSymbol symbol = m_manager.SymbolCreate();
            uint symbols_count = m_manager.SymbolTotal();


            //MTTickShort t = new MTTickShort();
            //m_manager.SelectedAdd("200AUD");
            //MTRetCode code = m_manager.TickLast("200AUD", out t);

            //Util.Info(code + "  " +  " " + t.bid);



            for (uint i = 0; i < symbols_count; i++)
            {
                m_manager.SymbolNext(i, symbol);
                tick.set_symbol_init(symbol.Symbol());
                m_manager.SelectedAdd(symbol.Symbol());
                //Util.Info(i+"");
                //MTTickShort t = new MTTickShort() ;

                //MTRetCode code = m_manager.TickLast(symbol.Symbol(),out t);

                //Util.Info(code + "  "+symbol.Symbol()+" "+t.bid);

            }

        }

        public void get_symbol(string symbol, MyTickSink tick)
        {
            tick.set_symbol_init(symbol);
            m_manager.SelectedAdd(symbol);
        }


        public void go(ulong ticket)
        {
            CIMTDeal deal = m_manager.DealCreate();
            MTRetCode code = m_manager.DealRequest(ticket, deal);
            Console.WriteLine(code);
        }

        public void fk()
        {
            m_manager.Disconnect();
        }

        public void get_price()
        {

            

            CIMTConSymbol sym = m_manager.SymbolCreate();
            string platform_id = get_platform_id();
            uint total = m_manager.SymbolTotal();
            //AliRedis redis = new AliRedis();
            //redis.connet();
            for (uint i = 0; i < total; i++)
            {
                MTTickShort ts;
                m_manager.SymbolNext(i, sym);
                m_manager.TickLast(sym.Symbol(), out ts);
                Util.Info("symbol启动初始化" + sym.Symbol() + ":" + ts.bid + "/" + ts.ask);
                //redis.set_value(platform_id + "_" + sym.Symbol(), ts.bid + "=" + ts.ask);
                tick_sink.set_price(sym.Symbol(), ts);
            }

        }

        public string get_platform_id()
        {
            return mArgs["name"].ToString();
        }

        /*
        public void runs_force2()
        {






            String[] x = File.ReadAllLines("upload.txt");
            Util.Info(x.Count()+"");


            //源数组
            //int x[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };
            //每组多少个
            int len = 300;
            //数组数量
            int y = x.Count();
            int left = y % len;
            int size = left == 0 ? y / len : y / len + 1;
            //当前页码
            int index = 1;
            for (int i = 1; i <= size; i++)
            {
                //新数组 数量
                int tempsize = len;
                if (i == size && left > 0)
                {
                    tempsize = left;
                }
                //新数组
                String[] temparray = new String[tempsize];
                for (int j = 0; j < tempsize; j++)
                {
                    temparray[j] = x[len * (index - 1) + j];
                }

                forceUpload2(temparray);


                //打印新数组
                
                //for (int k = 0; k < temparray.Count(); k++)
                //{

                //    Console.Write(temparray[k]);


                //}
                
                Util.Info("=====================" + index);
                index++;
            }











        }

        public void forceUpload2(string[] deals_array)
        {



            CIMTDealArray deals = m_manager.DealCreateArray();
            CIMTDeal deal = m_manager.DealCreate();
            string in_list = "[";
            string out_list = "[";






            for (int i = 0; i < deals_array.Count(); i++)
            {

                m_manager.DealRequest(ulong.Parse(deals_array[i]), deal);
                if (deal.Login() == 0 || deal.Volume() == 0) continue;
                //if (deal.Login() != 816222) continue;
                //Util.Info(deal.Login() + "----------------" + deal.Commission() + "--------------------" + deal.Profit());

                if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_IN || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_INOUT)
                {
                    in_list += "{";

                    in_list += "\"login\":\"" + deal.Login() + "\",";
                    in_list += "\"deal\":\"" + deal.Deal() + "\",";
                    in_list += "\"symbol\":\"" + deal.Symbol() + "\",";
                    in_list += "\"open_price\":\"" + deal.Price() + "\",";
                    in_list += "\"open_time\":\"" + deal.Time() + "\",";
                    in_list += "\"direct\":\"" + deal.Action() + "\",";
                    in_list += "\"ticket\":\"" + deal.PositionID() + "\",";
                    in_list += "\"commission\":\"" + deal.Commission() + "\",";
                    in_list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";

                    in_list += "\"comment\":\"\"";

                    in_list += "},";
                }
                else if (deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT || deal.Entry() == (uint)CIMTDeal.EnEntryFlag.ENTRY_OUT_BY)
                {
                    out_list += "{";

                    out_list += "\"login\":\"" + deal.Login() + "\",";
                    out_list += "\"deal\":\"" + deal.Deal() + "\",";
                    out_list += "\"symbol\":\"" + deal.Symbol() + "\",";
                    out_list += "\"close_price\":\"" + deal.Price() + "\",";
                    out_list += "\"close_time\":\"" + deal.Time() + "\",";

                    out_list += "\"ticket\":\"" + deal.PositionID() + "\",";
                    out_list += "\"commission\":\"" + deal.Commission() + "\",";
                    out_list += "\"lots\":\"" + (deal.Volume() / 100) + "\",";
                    out_list += "\"lots_closed\":\"" + (deal.VolumeClosed() / 100) + "\",";
                    out_list += "\"swap\":\"" + deal.Storage() + "\",";
                    out_list += "\"profit\":\"" + deal.Profit() + "\"";





                    out_list += "},";
                }

            }

            if (in_list.Contains("},"))
            {
                in_list = in_list.Substring(0, in_list.Length - 1);
            }

            if (out_list.Contains("},"))
            {
                out_list = out_list.Substring(0, out_list.Length - 1);
            }

            in_list += "]";
            out_list += "]";
            string json_in = "{\"list\":" + in_list + "}";
            string json_out = "{\"list\":" + out_list + "}";


            //Util.Info(json_in);
            //Util.Info(json_out);

            string postin = HttpPost(crm_host + "/index.php/index/Meta5/inject_open", "value=" + json_in);
            string postout = HttpPost(crm_host + "/index.php/index/Meta5/inject_close", "value=" + json_out);








            Util.Info("force->" + postin);
            Util.Info("force->" + postout);



        }

*/


        public void socket_tr()
        {
            Thread myThread = new Thread(socket);
            myThread.Start();


        }



        Socket serverSocket = null;
        private byte[] result = new byte[1024];
        private int port = 0;
        public void socket()
        {

            IPAddress ip = IPAddress.Parse("0.0.0.0");
            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //serverSocket = new Socket(SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(new IPEndPoint(ip, port));  //绑定IP地址：端口  
            
            serverSocket.Listen(1000);    //设定最多10个排队连接请求  
            Util.Info("启动监听{0}成功"+serverSocket.LocalEndPoint.ToString());
            //通过Clientsoket发送数据  
            Thread myThread = new Thread(ListenClientConnect);
            myThread.Start();
            //Console.ReadLine();

        }
        public int get_port()
        {
            return port;
        }

        public void set_port(int port)
        {
            Util.Info(port+"");
            this.port = port;
        }


        private void ListenClientConnect()
        {





            while (true)
            {

                try
                {
                    Socket clientSocket = serverSocket.Accept();
                    Util.Info("----");

                    clientSocket.Send(Encoding.ASCII.GetBytes("Server Say Hello"));
                    ReceiveMessage(clientSocket);
                    //Thread receiveThread = new Thread(ReceiveMessage);
                    //receiveThread.Start(clientSocket);
                }
                catch (Exception e)
                {
                    Util.Info("---上一次的bug2---");
                }



            }
        }

        private void ReceiveMessage(object clientSocket)
        {
            Socket myClientSocket = (Socket)clientSocket;

            try
            {
                myClientSocket.Send(Encoding.UTF8.GetBytes("Successful"));
            }
            catch (Exception e)
            {
                Util.Info("---上一次的bug---");
            }



            while (true)
            {
                try
                {
                    //通过clientSocket接收数据  
                    int receiveNumber = myClientSocket.Receive(result);
                    if (receiveNumber > 0)
                    {
                        string str = Encoding.ASCII.GetString(result, 0, receiveNumber);

                        //Util.Info(str);
                        if (str.Contains("notifydeal"))
                        {
                           // Util.Info(str);
                            ws_manage.notify_position(str);
                            continue;
                        }


                        string host = crm_host.Replace("https://", "").Replace("http://", "");


                        log.Info(str + " " + host);

                        if (str.Contains(host) == false)
                        {
                            log.Info("错误host");
                            return;
                        }
                        




                        if (str.Contains("restart"))
                        {




                            //System.Environment.CurrentDirectory + "\\ManageHolderService.exe"

                            System.Diagnostics.Process p = new System.Diagnostics.Process();
                            p.StartInfo.FileName = System.Environment.CurrentDirectory + "\\ManageHolderService.exe";
                            p.StartInfo.UseShellExecute = true;    //是否使用操作系统shell启动
                            p.StartInfo.RedirectStandardInput = false;//接受来自调用程序的输入信息
                            p.StartInfo.RedirectStandardOutput = false;//由调用程序获取输出信息
                            p.StartInfo.RedirectStandardError = false;//重定向标准错误输出
                            p.StartInfo.CreateNoWindow = false;//不显示程序窗口
                            p.Start();//启动程序

                            Process.GetCurrentProcess().Kill();


                        }
                        else if (str.Contains("load_balance"))
                        {
                            this.loadBalance();
                        }
                        else if (str.Contains("open_account"))
                        {
                            Util.Info("open_account");

                         

                            //500142,FDASFASDFSDFAD,real\wl\spring2\D01,100,rG6T47p6,39e5Jz5u,,FDASFASDF@QQ.AACC,1,1000,1
                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if(cmd.Length == 3)
                            {
                                values = cmd[2].Split(',');
                            }
                            //if (values != null)
                            //{
                            //    for (int i = 0; i < values.Length; i++)
                            //    {
                            //        Console.WriteLine(i + "  " + values[i]);
                            //    }
                            //}
                            CIMTUser user = m_manager.UserCreate();
                            user.Login(ulong.Parse(values[0]));
                            user.Name(HttpUtility.UrlDecode(values[1]) );
                            user.Group(values[2]);
                            user.Leverage(uint.Parse(values[3]));
                            values[7] = values[7].Replace('#', '_');
                            user.EMail(values[7]);
                            user.Rights(
                                CIMTUser.EnUsersRights.USER_RIGHT_DEFAULT 
                                &~ CIMTUser.EnUsersRights.USER_RIGHT_OTP_ENABLED






                                );

                            if (values[10] == "1")
                            {
                                //user.Rights(user.Rights() - CIMTUser.EnUsersRights.USER_RIGHT_ENABLED);
                            }



                            MTRetCode code =  m_manager.UserAdd(user, values[4], values[5]);
                            string code_str =  code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___"+code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);





                        }


                        else if (str.Contains("balance"))
                        {
                            Util.Info("balance");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,-100,Deposit
                            ulong id;
                            MTRetCode code = m_manager.DealerBalance(ulong.Parse(values[0]), double.Parse(values[1]), 2, values[2],out id);


                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);

                        }
                        else if (str.Contains("checkpsd"))
                        {
                            Util.Info("checkpsd");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            MTRetCode code =  m_manager.UserPasswordCheck(CIMTUser.EnUsersPasswords.USER_PASS_MAIN,  ulong.Parse(values[0]), values[1]);

                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }
                        else if (str.Contains("changepsd"))
                        {
                            Util.Info("changepsd");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            //MTRetCode code = m_manager.UserPasswordCheck(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            MTRetCode code = m_manager.UserPasswordChange(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }
                        else if (str.Contains("changegroup"))
                        {
                            Util.Info("changegroup");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            CIMTUser user = m_manager.UserCreate();
                            m_manager.UserGet(ulong.Parse(values[0]), user);
                            user.Group(values[1]);
                            MTRetCode code = m_manager.UserUpdate(user);


                            //MTRetCode code = m_manager.UserPasswordChange(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }
                        else if (str.Contains("changelevel"))
                        {
                            Util.Info("changelevel");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            CIMTUser user = m_manager.UserCreate();
                            m_manager.UserGet(ulong.Parse(values[0]), user);
                            user.Leverage(uint.Parse(values[1]));
                            MTRetCode code = m_manager.UserUpdate(user);


                            //MTRetCode code = m_manager.UserPasswordChange(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }
                        else if (str.Contains("changename"))
                        {
                            Util.Info("changename");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            CIMTUser user = m_manager.UserCreate();
                            m_manager.UserGet(ulong.Parse(values[0]), user);
                            user.Name(HttpUtility.UrlDecode(values[1]));
                            MTRetCode code = m_manager.UserUpdate(user);


                            //MTRetCode code = m_manager.UserPasswordChange(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }
                        else if (str.Contains("tradestatus"))
                        {
                            Util.Info("changename");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            CIMTUser user = m_manager.UserCreate();
                            m_manager.UserGet(ulong.Parse(values[0]), user);
                            if (values[1] == "1") 
                            {
                                user.Rights(user.Rights() & ~CIMTUser.EnUsersRights.USER_RIGHT_TRADE_DISABLED);
                            }else if (values[1] == "0")
                            {
                                user.Rights(user.Rights() | CIMTUser.EnUsersRights.USER_RIGHT_TRADE_DISABLED);
                            }





                            MTRetCode code = m_manager.UserUpdate(user);


                            //MTRetCode code = m_manager.UserPasswordChange(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }
                        else if (str.Contains("loginstatus"))
                        {
                            Util.Info("changename");

                            string[] cmd = str.Split('_');
                            string[] values = null;
                            if (cmd.Length == 2)
                            {
                                values = cmd[1].Split(',');
                            }
                            //816222,aaaabbbb

                            CIMTUser user = m_manager.UserCreate();
                            m_manager.UserGet(ulong.Parse(values[0]), user);
                            if (values[1] == "1")
                            {
                                user.Rights(user.Rights() | CIMTUser.EnUsersRights.USER_RIGHT_ENABLED);
                            }
                            else if (values[1] == "0")
                            {
                                user.Rights(user.Rights() & ~CIMTUser.EnUsersRights.USER_RIGHT_ENABLED);
                            }
                            MTRetCode code = m_manager.UserUpdate(user);


                            //MTRetCode code = m_manager.UserPasswordChange(CIMTUser.EnUsersPasswords.USER_PASS_MAIN, ulong.Parse(values[0]), values[1]);
                            string code_str = code.ToString();

                            Byte[] outBuffer = Encoding.ASCII.GetBytes("___" + code_str);
                            myClientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);
                            myClientSocket.Poll(1, SelectMode.SelectWrite);


                        }


                        else if (str.Contains("load_group"))
                        {
                            Util.Info("load_group");
                            this.loadGroup();
                        }
                        else if (str.Contains("load_symbol"))
                        {
                            this.loadSymbol();
                        }
                        
                        else if (str.Contains("newest_ticket"))
                        {
                            string[] strs = str.Split('=');
                            Util.Info(strs[(strs.Length - 1)]);
                            MongoUtil.set_key_value("newest_deal", strs[(strs.Length-1)]);



                        }
                        else if (str.Contains("last_ticket"))
                        {
                            string[] strs = str.Split('=');
                            MongoUtil.set_key_value("last_deal", strs[(strs.Length - 1)]);
                        }



                        Util.Info(String.Format( "接收客户端{0}消息{1}----{2}", myClientSocket.RemoteEndPoint.ToString(), str, receiveNumber));

                    }
                    else
                    {
                        Util.Info("xxxxxx");
                        break;
                    }
                }
                catch (Exception ex)
                {
                    Util.Info(ex.Message);
                    myClientSocket.Shutdown(SocketShutdown.Both);
                    myClientSocket.Close();
                    Util.Info("xxxxxx");
                    break;
                }
            }
        }

        public string get_crm_host()
        {
            return crm_host;
        }

        public void set_crm_host(string host)
        {
            this.crm_host = host;
        }

        public string loadGroup()
        {
            uint total = m_manager.GroupTotal();
            CIMTConGroup g = m_manager.GroupCreate();

            string str = "";
            string min_lots = "0.01";
            string max_lots = "100";
            string str_all = "";
            for (uint i = 0; i < total; i++)
            {

                str = "";
                m_manager.GroupNext(i, g);
                str += g.Group()/*.Replace("real\\", "")*/
                            +"-_-_---";//nameg.MarginStopOut()
                str += g.MarginStopOut() + "-_-_---";//so
                CIMTConGroup.EnTradeFlags p = g.TradeFlags();

                str += (p.HasFlag(CIMTConGroup.EnTradeFlags.TRADEFLAGS_EXPERTS) ? "1" : "0") + "-_-_---";//ea


                uint a = g.SymbolTotal();
                // Util.Info(a);
                CIMTConGroupSymbol s = m_manager.GroupSymbolCreate();
                string temp = "[";
                for (uint j = 0; j < a; j++)
                {

                    g.SymbolNext(j, s);
                    temp += "{";
                    temp += "\"name\":\"" + s.Path().Replace("\\", "\\\\") + "\",";
                    temp += "\"margin_rates\":\"" + (s.MarginRateInitial(0) > 10000 ? "default" : "" + s.MarginRateInitial(0) * 100)
                        + "/" + (s.MarginRateInitial(2) > 10000 ? "default" : "" + s.MarginRateInitial(2) * 100)
                        + "/" + (s.MarginRateInitial(4) > 10000 ? "default" : "" + s.MarginRateInitial(4) * 100)
                        + "/" + (s.MarginRateInitial(6) > 10000 ? "default" : "" + s.MarginRateInitial(6) * 100) + "/" + "\",";

                    //Util.Info(s.VolumeMin()*1.0/10000);


                    temp += "\"min\":\"" + (s.VolumeMin() > 1000000 ? min_lots : (s.VolumeMin() * 1.0 / 10000) + "") + "\",";
                    temp += "\"max\":\"" + (s.VolumeMax() > 1000000 ? max_lots : (s.VolumeMax() * 1.0 / 10000) + "") + "\",";
                    temp += "\"spread\":\"" + (s.SpreadDiff() > 1000000 ? 0 : s.SpreadDiff()) + "\"";
                    //名称
                    //Util.Info("================="+s.Path());
                    //最小交易,最大，步长
                    //Util.Info((s.VolumeMin()>1000000?" default " : s.VolumeMin()+"") + "================="  );
                    //加点
                    //Util.Info("=================" + s.SpreadDiff());

                    temp += "}";

                    if (j < a - 1) temp += ",";

                }
                str += temp + "]-_-_---";





                temp = "[";
                //commission
                CIMTConCommission commission = m_manager.GroupCommissionCreate();
                for (uint k = 0; k < g.CommissionTotal(); k++)
                {
                    temp += "{";
                    g.CommissionNext(k, commission);
                    CIMTConCommission.EnCommMode m = commission.Mode();

                    temp += "\"name\":\"" + commission.Name() + "\",";
                    temp += "\"path\":\"" + commission.Path().Replace("\\", "\\\\") + "\",";
                    temp += "\"mode\":\"" + commission.Mode() + "\",";


                    CIMTConCommTier t = m_manager.GroupTierCreate();
                    commission.TierNext(0, t);
                    //Util.Info(m + " " + commission.Name() + "" + commission.Path() + "  " + t.Mode() +"  "+t.Value());
                    temp += "\"commission_mode\":\"" + t.Mode() + "\",";
                    temp += "\"commission_value\":\"" + (t.Value() * 2) + "\"";

                    temp += "}";

                    if (k < g.CommissionTotal() - 1) temp += ",";

                }
                str += temp + "]";
                string mstr = HttpPost(crm_host + "/index.php/setting/group/saveUpdateGroup", "value=" + System.Web.HttpUtility.UrlEncode(str, Encoding.UTF8));
                Util.Info(mstr);
                str_all += str + "____xxx___";

            }



            return str_all;
        }


        public string loadSymbol()
        {
            CIMTConSymbol symbol = m_manager.SymbolCreate();
            uint symbols_count = m_manager.SymbolTotal();
            string str_all = "";
            string str = "";
            for (uint i = 0; i < symbols_count; i++)
            {
                m_manager.SymbolNext(i, symbol);
                //str = symbol.Symbol() + "-_-_---" + symbol.CurrencyBase() + "-_-_---" + symbol.CurrencyProfit() + "-_-_---" + symbol.CurrencyMargin()
                //    + "-_-_---" + ChangeDataToD(symbol.Point().ToString()) + "-_-_---" + symbol.ContractSize() + "-_-_---" + symbol.CalcMode()+"////__|||";

                String[] symbol_arr = symbol.Path().Split('\\');
                String path = "";
                for (int j = 0; j < symbol_arr.Length - 1; j++)
                {

                    if (symbol_arr[j].Length > 0)
                        path += symbol_arr[j] + "\\";


                }

                Util.Info(symbol.Path() + "  " + path);




                str = symbol.Symbol() + "-_-_---" + symbol.CurrencyBase() + "-_-_---" + symbol.CurrencyProfit() + "-_-_---" + symbol.CurrencyMargin()
                   + "-_-_---" + ChangeDataToD(symbol.Point().ToString()) + "-_-_---" + symbol.ContractSize() + "-_-_---" + symbol.CalcMode() + "-_-_---" + path;





                string mstr = HttpPost(crm_host + "/index.php/setting/symbol/saveUpdateSymbol", "value=" + System.Web.HttpUtility.UrlEncode(str, Encoding.UTF8));
                Util.Info(mstr);

                str_all += str;

            }
            return str_all;


        }

        public string loadBalance()
        {
            uint total = m_manager.GroupTotal();
            CIMTAccountArray accounts = m_manager.UserCreateAccountArray();

            m_manager.UserAccountRequestArray("*", accounts);

            
            CIMTAccount aa = null;
            string append = "";
            for (uint i = 0; i < accounts.Total(); i++)
            {
                aa = accounts.Next(i);
                if (append != "") append += ",";
                append += aa.Login() + "=" + aa.Balance();
                if ((i > 0 && i % 100 == 0) || i == accounts.Total() - 1)
                {
                    //Util.Info(i + ">>>>>>>>>>>"+ aa.Balance());
                    //Util.Info(append);

                    string mstr = HttpPost(crm_host + "/index.php/index/meta5/inject_balance_bash", "value=" + System.Web.HttpUtility.UrlEncode(append, Encoding.UTF8));
                    Util.Info(mstr);

                    append = "";


                }



                //Util.Info(accounts.Next(i).Login());
            }






            return "";
        }
        public string HttpPost(string Url, string postDataStr)
        {

            Util.Info("debug="+Url + "  "+postDataStr);
            


            string result = string.Empty;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12; //加上这一句

            try
            {

                //注意提交的编码 这边是需要改变的 这边默认的是Default：系统当前编码
                byte[] postData = Encoding.UTF8.GetBytes(postDataStr);

                // 设置提交的相关参数 
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                Encoding myEncoding = Encoding.UTF8;
                request.Method = "POST";
                request.KeepAlive = false;
                request.Timeout = 600000;
                request.AllowAutoRedirect = true;
                request.ContentType = "application/x-www-form-urlencoded";
                //request.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727; .NET CLR  3.0.04506.648; .NET CLR 3.5.21022; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)";
                request.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)";
                request.ContentLength = postData.Length;
                request.ProtocolVersion = HttpVersion.Version10;


                // 提交请求数据 
                System.IO.Stream outputStream = request.GetRequestStream();
                outputStream.Write(postData, 0, postData.Length);
                outputStream.Close();

                HttpWebResponse response;
                Stream responseStream;
                StreamReader reader;
                string srcString;
                response = request.GetResponse() as HttpWebResponse;
                responseStream = response.GetResponseStream();
                reader = new System.IO.StreamReader(responseStream, Encoding.GetEncoding("UTF-8"));
                srcString = reader.ReadToEnd();
                result = srcString;   //返回值赋值
                reader.Close();

            }
            catch (Exception e)
            {
                Util.Info("fuck...." + e.ToString() + "-" + Url);
                result = "";
            }
            return result;


        }
        public void set_websocket(WebSocketManager ws_manage)
        {
            this.ws_manage = ws_manage;
        }





        private String ChangeDataToD(string strData)
        {

            if (strData.Contains("E"))
            {
                Decimal dData = 0.0M;
                dData = Convert.ToDecimal(Decimal.Parse(strData.ToString(), System.Globalization.NumberStyles.Float));
                return dData + "";
            }
            else
            {
                return strData;
            }

        }


    }
}
//+------------------------------------------------------------------+
