﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaQuotes.MT5ManagerAPI;
using MetaQuotes.MT5CommonAPI;
using BalanceExample.NET;
using AliLib4net;
using ManageHolderService;

namespace Meta5API.NET
{
    class MyManageSink: CIMTManagerSink
    {
        private CManager manage;
        private AlixLog log;
        public MyManageSink(CManager manage)
        {
            RegisterSink();
            this.manage = manage;
            log = new AlixLog();
        }

        public override void OnConnect() {
            //manage.Log("waring", "已连接");
            Util.Info("OnConnect");
            manage.sink_restart();
        }
        public override void OnDisconnect()
        {
            //manage.Log("waring", "断开连接");
            Util.Info("OnDisconnect");

        }
        public override void OnTradeAccountSet(MTRetCode retcode, long request_id, CIMTUser user, CIMTAccount account, CIMTOrderArray orders, CIMTPositionArray positions)
        {

        }








    }
}
