﻿using BalanceExample.NET;
using Meta5API.NET;
using SuperWebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AliLib4net;
using SuperSocket.SocketBase.Config;
using ManageHolderService;

namespace WebSocketDemo
{
      class WebSocketManager
    {
         CManager manage = null; 
         MyTickSink tick = null;
         Dictionary<string, WebSocketSession> sessionDics = new Dictionary<string, WebSocketSession>();
         WebSocketServer webSocketServer;
         Dictionary<string, List<string>> id_symbols;
         Dictionary<string, List<string>> symbol_ids;

        Dictionary<string, List<string>> id_bids = new Dictionary<string, List<string>>();
        Dictionary<string, List<string>> bid_ids = new Dictionary<string, List<string>>();

        Dictionary<WebSocketSession,string> sessionDics2 = new Dictionary<WebSocketSession,string>();
         private string platform_id;
        private AlixLog log;

        public  void Init(int port, CManager manage,MyTickSink tick)
        {
            this.manage = manage;
            this.tick = tick;
            var ip = "0.0.0.0";//GetLocalIP();
            webSocketServer = new WebSocketServer();
            log = new AlixLog();

            ServerConfig serverConfig = new ServerConfig();
            serverConfig.Ip = ip;
            serverConfig.Port = port;
            serverConfig.MaxConnectionNumber = 1000;

            //开启SSL wss://
            //serverConfig.Security = "tls";

            //FilePath证书的绝对路径配置文件读取,Password证书密码
            //CertificateConfig objCertificateConfig = new CertificateConfig() { FilePath = "D:\\server.pfx", Password = "123456" };
            //serverConfig.Certificate = objCertificateConfig;


            var isSetup = webSocketServer.Setup(serverConfig);

            if(isSetup == false)
            {
                throw new Exception("websocket启动失败");
            }

            //var isSetup = webSocketServer.Setup(ip, port);
            Util.Info("WebSocketManager： 服务器端启动 Ip="+ip + (isSetup ? " 成功" : " 失败"));




            if (!isSetup)
                return;

            id_symbols = new Dictionary<string, List<string>>();
            symbol_ids = new Dictionary<string, List<string>>();


            webSocketServer.NewSessionConnected += WebSocketServer_NewSessionConnected;
            webSocketServer.SessionClosed += WebSocketServer_SessionClosed;
            webSocketServer.NewMessageReceived += WebSocketServer_NewMessageReceived;

            var isStart = webSocketServer.Start();
            Util.Info("WebSocketManager： 服务器端侦听" + (isStart ? "成功" : "失败"));
            platform_id = manage.get_platform_id();
        }

        /// <summary>
        /// 接收消息
        /// </summary>
        /// <param name="session"></param>
        /// <param name="value"></param>
        private  void WebSocketServer_NewMessageReceived(WebSocketSession session, string value)
        {
            //Util.Info("WebSocketManager： 接收消息 \r\n" + value);
            //Console.WriteLine("WebSocketManager： 接收消息 \r\n" + value);
            string[] values = value.Split('=');
            if (values.Length != 2) return;

            if (values[0] == "id")
            {
                if (!string.IsNullOrWhiteSpace(values[1]))
                {
                    if (!sessionDics.ContainsKey(values[1]))
                    {
                        sessionDics.Add(values[1], session);
                        sessionDics2.Add(session, values[1]);
                        id_symbols[values[1]] = new List<string>();
                        id_bids[values[1]] = new List<string>();
                    }
                    else
                    {
                        sessionDics[values[1]] = session;
                    }


                }
            }
            else if (values[0] == "sub")
            {
                string id = sessionDics2[session];
                //Console.WriteLine("add ok");
                if (id_symbols[id].Contains(values[1]) == false)
                {

                    id_symbols[id].Add(values[1]);
                    manage.get_symbol(values[1], tick);
                    //Console.WriteLine("add ok");
                    //SendMsgToRemotePoint(values[1], values[1]+"="+manage.get_price(values[1]));
                }


                if (symbol_ids.ContainsKey(values[1]) == false)
                {
                    symbol_ids.Add(values[1], new List<string>());
                }


                if (symbol_ids[values[1]].Contains(id) == false)
                {
                    symbol_ids[values[1]].Add(id);
                }


            }
            else if (values[0] == "get")
            {
                string id = sessionDics2[session];
                string mytick = tick.get_tick(values[1]);
                if (mytick != "")
                {

                }
                else
                {
                    //AliRedis redis = new AliRedis();
                    //redis.connet();
                    //mytick = redis.get_value(platform_id + "_" + values[1]);
                }
                SendMsgToRemotePoint2(id, values[1] + "=" + mytick);




            }
            else if (values[0] == "bid")
            {
                string id = sessionDics2[session];

                if (id_bids[id].Contains(values[1]) == false)
                {
                    id_bids[id].Add(values[1]);
                }

                if (bid_ids.ContainsKey(values[1]) == false)
                {
                    bid_ids.Add(values[1], new List<string>());
                }


                if (bid_ids[values[1]].Contains(id) == false)
                {
                    bid_ids[values[1]].Add(id);
                }

            }
            else if (values[0] == "notifydeal")
            {

                




                

            }


                //test();


            }
        

        /// <summary>
        /// 下线
        /// </summary>
        /// <param name="session"></param>
        /// <param name="value"></param>
        private  void WebSocketServer_SessionClosed(WebSocketSession session, SuperSocket.SocketBase.CloseReason value)
        {
            Util.Info(string.Format("WebSocketManager：{0} {1}{2}下线", value, session.RemoteEndPoint,sessionDics2[session]));
            string id = sessionDics2[session];
            id_symbols[id].Clear();
            id_symbols.Remove(id);

            id_bids[id].Clear();
            id_bids.Remove(id);



            //所有品种的session全部删除
            foreach (var v in symbol_ids)
            {
                v.Value.Remove(sessionDics2[session]);
                
            }

            foreach (var v in bid_ids)
            {
                v.Value.Remove(sessionDics2[session]);

            }





            //test();

        }






         void testaaa()
        {
            string str = "id-symbol:\r\n数量：" + id_symbols.Count() + "\r\n";
            str += "symbol-id:\r\n数量：" + symbol_ids.Count() + "\r\n";
            foreach (var v in symbol_ids)
            {

                str += v.Key + "ids 数量=" + v.Value.Count + "    ";
            }
            Util.Info(str);
        }

        /// <summary>
        /// 上线
        /// </summary>
        /// <param name="session"></param>
        private  void WebSocketServer_NewSessionConnected(WebSocketSession session)
        {
            Util.Info(string.Format("WebSocketManager：{0}上线", session.RemoteEndPoint));
        }

        /// <summary>
        /// 发送消息到客户端
        /// </summary>
        /// <param name="value"></param>
        /// <param name="msg"></param>
        public  void SendMsgToRemotePoint(string symbol, string msg)
        {

            List<string> sessionlist = symbol_ids[symbol];
            for(int i = 0; i < sessionlist.Count; i++)
            {
                if (sessionDics.ContainsKey(sessionlist[i]))
                {
                    var webSocketSession = sessionDics[sessionlist[i]];
                    if (webSocketSession != null)
                    {
                        webSocketSession.Send(msg);
                    }
                }



            }

        }


        public void notify_position(string msg)
        {
            Console.WriteLine("从...进来了订单信息->"+msg);
            
            string[] strs0 = msg.Split('=');
            if (strs0.Length != 2) return;

            string[] strs = strs0[1].Split(',');



            for (int h = 0; h < strs.Length; h++)
            {
                List<string> sessionlist = bid_ids[strs[h]];
                for (int i = 0; i < sessionlist.Count; i++)
                {
                    if (sessionDics.ContainsKey(sessionlist[i]))
                    {
                        var webSocketSession = sessionDics[sessionlist[i]];
                        if (webSocketSession != null)
                        {
                            webSocketSession.Send("notifydeal");
                        }
                    }



                }



            }
            
        }



        public void SendMsgToRemotePoint2(string id, string msg)
        {

            
            if (sessionDics.ContainsKey(id))
            {
                var webSocketSession = sessionDics[id];
                if (webSocketSession != null)
                {
                    webSocketSession.Send(msg);
                }
            }



            

        }





        /// <summary>
        /// 获取本地IP等信息
        /// </summary>
        /// <returns></returns>
        public  string GetLocalIP()
        {
            //本机IP地址 
            string strLocalIP = "";
            //得到计算机名 
            string strPcName = Dns.GetHostName();
            //得到本机IP地址数组 
            IPHostEntry ipEntry = Dns.GetHostEntry(strPcName);
            //遍历数组 
            foreach (var IPadd in ipEntry.AddressList)
            {
                //判断当前字符串是否为正确IP地址 
                if (IsRightIP(IPadd.ToString()))
                {
                    //得到本地IP地址 
                    strLocalIP = IPadd.ToString();
                    //结束循环 
                    break;
                }
            }

            //返回本地IP地址 
            return strLocalIP;
        }
        /// <summary>
        /// 判断是否为正确的IP地址
        /// </summary>
        /// <param name="strIPadd">需要判断的字符串</param>
        /// <returns>true = 是 false = 否</returns>
        private  bool IsRightIP(string strIPadd)
        {
            //利用正则表达式判断字符串是否符合IPv4格式
            if (Regex.IsMatch(strIPadd, "[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}"))
            {
                //根据小数点分拆字符串
                string[] ips = strIPadd.Split('.');
                if (ips.Length == 4 || ips.Length == 6)
                {
                    //如果符合IPv4规则
                    if (System.Int32.Parse(ips[0]) < 256 && System.Int32.Parse(ips[1]) < 256 & System.Int32.Parse(ips[2]) < 256 & System.Int32.Parse(ips[3]) < 256)
                        //正确
                        return true;
                    //如果不符合
                    else
                        //错误
                        return false;
                }
                else
                    //错误
                    return false;
            }
            else
                //错误
                return false;
        }
    }
}