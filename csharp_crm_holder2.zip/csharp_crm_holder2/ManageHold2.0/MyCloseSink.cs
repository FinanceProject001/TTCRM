﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaQuotes.MT5ManagerAPI;
using MetaQuotes.MT5CommonAPI;
using BalanceExample.NET;
using AliLib4net;
using System.Xml.Linq;
using ManageHolderService;

namespace Meta5API.NET
{
    class MyCloseSink: CIMTDealerSink
    {
        private CManager manage;
        private AlixLog log;
        public MyCloseSink(CManager manage)
        {
            RegisterSink();
            this.manage = manage;
            log = new AlixLog();
        }

        static String host = "";
        static String name = "";
        static String psd = "";
        static String db = "";
        static String port = "";

        /*
        public MySqlConnection getConnect()
        {
            if (host == "" || name == "" || psd == "" || db == "" || port == "")
            {

                XDocument document = XDocument.Load("config.xml");
                //获取到XML的根元素进行操作
                XElement root = document.Root;

                host = root.Element("host").Value;
                name = root.Element("name").Value;
                psd = root.Element("psd").Value;
                db = root.Element("db").Value;
                port = root.Element("port").Value;

            }
            //Util.Info("server=" + host + ";user id=" + name + ";Password=" + psd + ";database=" + db + ";persist security info=False;port=" + port + "");
            return new MySqlConnection("server=" + host + ";user id=" + name + ";Password=" + psd + ";database=" + db + ";persist security info=False;port=" + port + "");

        }
        */
        public override void OnDealerAnswer(CIMTRequest request)
        {
            Util.Info("code=" + request.ResultRetcode());
            if (request.ResultRetcode()== MTRetCode.MT_RET_REQUEST_PLACED || request.ResultRetcode() == MTRetCode.MT_RET_REQUEST_DONE)
            {
                

                //Util.Info("dealId=" + request.ResultDeal());
                //Util.Info("dealComment=" + request.ResultComment());
                //Util.Info("dealOrder=" + request.ResultOrder());
            }
            else if (request.ResultRetcode() == MTRetCode.MT_RET_REQUEST_POSITION_CLOSED)
            {
                //平仓失败
                ulong id = request.Position();
                /*
                MySqlConnection conn = getConnect();
                conn.Open();
                String sql = "select * from position where target_position = " + id;
                MySqlCommand msqlCommand = new MySqlCommand();                
                msqlCommand.Connection = conn;                
                msqlCommand.CommandText = sql;               
                MySqlDataReader reader = msqlCommand.ExecuteReader();
                
                
                long close_lots = 0;
                long close_lots_target = 0;
                if (reader.Read())
                {
                     close_lots = reader.GetInt64(6);
                     close_lots_target = reader.GetInt64(10);

                }
                msqlCommand.Dispose();
                reader.Close();
                reader.Dispose();

                sql = "update position set close_lots="+close_lots+",close_lots_target="+ close_lots_target+ ",source_div=0,target_div=0 where target_position ="+id;
                    
                    msqlCommand = new MySqlCommand();
                    
                    msqlCommand.Connection = conn;
                    msqlCommand.CommandText = sql;
                    msqlCommand.ExecuteNonQuery();
                    
                    msqlCommand.Dispose();
                    
                    manage.Log("error", "平仓失败，已平仓的错误，SQL语句=‘" + sql + "’");
                    

               
                
                
                conn.Close();
                conn.Dispose();
                */
                
            }
            
            else
            {

                Util.Info("平仓失败，dealId=‘" + request.Position() + "’，deal_result=" + request.ResultRetcode());
                
                

            }



            



        }








    }
}
