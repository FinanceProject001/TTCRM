﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaQuotes.MT5CommonAPI;
//using System.Data.SQLite;
using BalanceExample.NET;
using System.Collections;
using System.IO;
using aliManageGendan;
using System.Xml.Linq;
using System.Net;
using System.Threading;
using WebSocketDemo;
using AliLib4net;
using ManageHolderService;

namespace Meta5API.NET
{
    class MyTickSink: CIMTTickSink
    {

        private CManager manage;
        //private AliRedis redis;
        private string platform_id;
        private AlixLog log;
        int sleep = 500;
        ulong count = 0;
        Dictionary<string, MTTickShort> myDictionary;
        Dictionary<string, ulong> last_count;
        WebSocketManager wb = null;
        




        public MyTickSink( CManager manage)
        {
            log = new AlixLog();
            wb = new WebSocketManager();
            wb.Init(manage.get_port()-10000,manage,this);
            this.manage = manage;
            manage.set_websocket(wb);
            //redis = new AliRedis();
            //redis.connet();
            platform_id = manage.get_platform_id();
            myDictionary = new Dictionary<string, MTTickShort>();
            //startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));
            RegisterSink();
            
            last_count = new Dictionary<string, ulong>();
            //manage.get_all_symbol(this);
            new Task(() =>
            {

                while (true)
                {
                    count++;

                    
                    Thread.Sleep(sleep);

                }




            }).Start();





        }

        public void set_symbol_init(string sym)
        {
            last_count[sym] = 0;
        }

        public string get_tick(string symbol)
        {


            string str = "";

            try
            {
                MTTickShort tick = myDictionary[symbol];
                if (tick.bid == 0 || tick.ask == 0) return "";
                str = tick.bid + "=" + tick.ask;
            }catch(Exception e)
            {
                str = "";
            }
            
            return str;

        }

        public void set_price(string symbol,MTTickShort tick)
        {
            myDictionary[symbol] = tick;
        }





        public override MTRetCode HookTick(int feeder, ref MTTick tick) {
            return 0;
        }
        public override MTRetCode HookTickStat(int feeder, ref MTTickStat tstat) {
            return 0;
        }
        public override void OnTick(int feeder, MTTick tick) {
            
        }
        public override void OnTick(string symbol, MTTickShort tick) {

            //Util.Info(symbol + "bbb");

            if (Util.isdebug)
            {
                Console.WriteLine(last_count[symbol]+"----------------" + count);
            }
            if (last_count[symbol] == count)
            {
                //Util.Info(symbol+"已过滤"+count);
                return;
            }
            myDictionary[symbol] = tick;
            //if("EURUSD"==symbol)
            wb.SendMsgToRemotePoint(symbol, symbol+"="+tick.bid+"="+tick.ask);

            if (Util.isdebug)
            {
                Console.WriteLine(symbol + "=" + tick.bid + "=" + tick.ask);
            }



            last_count[symbol] = count;
            //redis.set_value(platform_id+"_"+symbol,tick.bid+"="+tick.ask);
            //Util.Info("已发送" + count);
        }
        public override void OnTickStat(MTTickStat tick) {
            
        }




        public override void OnTickStat(int feeder, MTTickStat tstat) {
        }





          

    }
}
