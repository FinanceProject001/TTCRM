﻿using ManageHolderService;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ManageHold2._0
{
    class MongoUtil
    {

        private static IMongoDatabase db = null;
        private static MongoClient client;
        private static Hashtable args;

        public static IMongoDatabase  getconnection()
        {
            try
            {
                if(db != null && client != null)
                {
                    client.ListDatabases().ToList().Count();
                    return db;
                }


                args = Util.loadXml();

                string connStr = "mongodb://" + args["mongo_name"] + ":" + args["mongo_psd"] + "@" 
                    + args["mongo_ip"] + ":" + args["mongo_port"] + "/" + args["mongo_db"];
                Console.WriteLine(connStr);
                client = new MongoClient(connStr);
                int x = client.ListDatabases().ToList().Count();
                db = client.GetDatabase((string)args["mongo_db"]);

                Console.WriteLine("mongo连接成功");
                return db;
            }
            catch(Exception e)
            {
                Thread.Sleep(5000);
                Console.WriteLine(e.Message);
                Util.Info(e.Message+e.StackTrace);
                Console.WriteLine("准备重新连接");
                return getconnection( );
            }
        }

        public static bool find_count(string table_name ,string key,string value)
        {
            try
            {
                var collection = db.GetCollection<BsonDocument>(args["port"] + table_name);
                FilterDefinitionBuilder<BsonDocument> builderFIlter = Builders<BsonDocument>.Filter;
                FilterDefinition<BsonDocument> filter = builderFIlter.Eq(key, value);
                var list = collection.Find(filter).ToList();
                if (list == null) return false;
                return list.Count > 0;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message+e.StackTrace);
                return false;
            }
            

        }
        public static IMongoCollection<BsonDocument> get_collecting(string table_name)
        {
            try
            {
                var collection = db.GetCollection<BsonDocument>(args["port"] + table_name);

                return collection;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + e.StackTrace);
                return null;
            }
        }

        public static string get_value_by_key(string key)
        {
            getconnection();
            var collection = db.GetCollection<BsonDocument>(args["port"]+"setting");
            FilterDefinitionBuilder<BsonDocument> builderFIlter = Builders<BsonDocument>.Filter;
            FilterDefinition<BsonDocument> filter = builderFIlter.Eq("key", key);
            List<BsonDocument> list = collection.Find(filter).ToList();
            if (list.Count <= 0)
            {
                return "";
            }
            else
            {
                return list[0].GetValue("value").ToString();
            }

        }
        public static void set_key_value(string key,string value)
        {
            string dt = DateTime.Now.ToString();
            getconnection();
            BsonDocument doc = new BsonDocument();
            
            doc.Add("key", key);
            doc.Add("value", value);
            var collection = db.GetCollection<BsonDocument>(args["port"] + "setting");
            FilterDefinitionBuilder<BsonDocument> builderFIlter = Builders<BsonDocument>.Filter;
            FilterDefinition<BsonDocument> filter = builderFIlter.Eq("key", key);
            var list = collection.Find(filter).ToList();
            if(list.Count == 0)
            {
                doc.Add("ct", dt);
                doc.Add("ut", dt);
                collection.InsertOne(doc);
            }
            else
            {
                var update = Builders<BsonDocument>.Update.Set("value", value).Set("ut",dt);
                collection.UpdateOne(filter, update);
            }





        }






        public static void set_orders(string deal, int status)
        {
            string dt = DateTime.Now.ToString();
            getconnection();
            BsonDocument doc = new BsonDocument();

            doc.Add("deal", deal);
            doc.Add("status", status);
            var collection = db.GetCollection<BsonDocument>(args["port"] + "orders");
            FilterDefinitionBuilder<BsonDocument> builderFIlter = Builders<BsonDocument>.Filter;
            FilterDefinition<BsonDocument> filter = builderFIlter.Eq("deal", deal);
            var list = collection.Find(filter).ToList();
            if (list.Count == 0)
            {
                doc.Add("ct", dt);
                doc.Add("ut", dt);
                collection.InsertOne(doc);
            }
            else
            {
                var update = Builders<BsonDocument>.Update.Set("status", status).Set("ut", dt);
                collection.UpdateOne(filter, update);
            }





        }


        public static int get_status_by_deal(string deal)
        {
            getconnection();
            var collection = db.GetCollection<BsonDocument>(args["port"] + "orders");
            FilterDefinitionBuilder<BsonDocument> builderFIlter = Builders<BsonDocument>.Filter;
            FilterDefinition<BsonDocument> filter = builderFIlter.Eq("deal", deal);
            List<BsonDocument> list = collection.Find(filter).ToList();
            if (list.Count <= 0)
            {
                return -1;
            }
            else
            {
                return list[0].GetValue("status").ToInt32();
            }

        }




        public void test()
        {
            var collection = db.GetCollection<BsonDocument>("ali");
            FilterDefinitionBuilder<BsonDocument> builderFIlter = Builders<BsonDocument>.Filter;
            FilterDefinition<BsonDocument> filter = builderFIlter.Eq("test", 3);
            var update = Builders<BsonDocument>.Update.Set("test", "36");


            collection.UpdateMany(filter, update);//多个。如果是One ，只改第一个


        }





    }
}
