﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetaQuotes.MT5ManagerAPI;
using MetaQuotes.MT5CommonAPI;
using BalanceExample.NET;
using AliLib4net;
using ManageHolderService;

namespace Meta5API.NET
{
    class MyOpenSink: CIMTDealerSink
    {
        private CManager manage;
        private AlixLog log;
        public MyOpenSink(CManager manage)
        {
            RegisterSink();
            this.manage = manage;
            log = new AlixLog();
        }

        public override void OnDealerAnswer(CIMTRequest request)
        {

            if(request.ResultRetcode()== MTRetCode.MT_RET_REQUEST_PLACED || request.ResultRetcode() == MTRetCode.MT_RET_REQUEST_DONE)
            {
                

                //Util.Info("dealId=" + request.ResultDeal());
                //Util.Info("dealComment=" + request.ResultComment());
                //Util.Info("dealOrder=" + request.ResultOrder());
            }else
            {

                Util.Info("开仓失败，dealComment=‘" + request.Comment() + "’，deal_result=" + request.ResultRetcode());
                
                //manage.sendMail("开仓失败", "开仓失败，dealComment=‘" + request.Comment() + "’，deal_result=" + request.ResultRetcode());

            }



            



        }








    }
}
