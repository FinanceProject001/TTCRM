﻿using BalanceExample.NET;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using AliLib4net;
using ManageHolderService;
using ManageHold2._0;

namespace aliManageGendan
{
    class DealModal
    {

        private uint deal_entry = 0;
        private uint deal_action = 0;
        private string deal_comment = "";
        private ulong deal_login = 0;
        private ulong deal_position_id = 0;
        private ulong deal_volume = 0;
        private ulong deal_volume_closed = 0;
        private string deal_symbol = "";
        private ulong deal_deal_id = 0;
        private double price = 0;
        private long time;
        private double commission = 0;
        private double profit = 0;
        private double storage = 0;
        private string deal_lp_ticket = "";
        private CManager manage;

        private AlixLog log;



        List<DealModal> list = null;


        public void run_thread()
        {

            while (true)
            {


                for (int i = 0; i < list.Count; i++)
                {
                    //Util.Info("正在处理"+list[i].deal_position_id+"的订单");
                    this.aaabbb(list[i]);
                    list.RemoveAt(i);
                    //Thread.Sleep(100);



                }


                
                Thread.Sleep(3000);


            }






        }




        public DealModal(CManager manage)
        {
            this.manage = manage;
            log = new AlixLog();
            if (list == null)
            {
                list = new List<DealModal>();
            }

            Thread t = new Thread(new ThreadStart(run_thread));
            t.Start();

        }

        public DealModal(uint deal_action, uint deal_entry, string deal_comment, ulong deal_login, ulong deal_position_id, ulong deal_volume, ulong deal_volume_closed, string deal_symbol, ulong deal_deal_id, double price, long time, double commission, double profit, double storage, string deal_lp_ticket)
        {
            this.deal_comment = deal_comment;
            this.deal_entry = deal_entry;
            this.deal_action = deal_action;
            this.deal_login = deal_login;
            this.deal_position_id = deal_position_id;
            this.deal_volume = deal_volume;
            this.deal_volume_closed = deal_volume_closed;
            this.deal_symbol = deal_symbol;
            this.deal_deal_id = deal_deal_id;
            this.price = price;
            this.time = time;
            this.commission = commission;
            this.profit = profit;
            this.storage = storage;
            this.deal_lp_ticket = deal_lp_ticket;

        }


        public void input_queue(uint deal_action, uint deal_entry, string deal_comment, ulong deal_login, ulong deal_position_id, ulong deal_volume, ulong deal_volume_closed, string deal_symbol, ulong deal_deal_id, double price, long time, double commission, double profit, double storage, string deal_lp_ticket)
        {

            list.Add(new DealModal(deal_action, deal_entry, deal_comment, deal_login, deal_position_id, deal_volume, deal_volume_closed, deal_symbol, deal_deal_id, price, time, commission, profit, storage, deal_lp_ticket));



        }



        public void aaabbb(DealModal x)
        {
            MongoUtil.set_key_value("newest_deal", x.deal_deal_id+"");
            if (x.deal_entry == 0 && 2 == x.deal_action)  //出入金，update一下余额
            {
                string post = this.HttpPost(manage.get_crm_host() + "/index.php/index/meta5/inject_balance", "value=" + x.deal_login + "_" + manage.getBalanceBylogin(x.deal_login));
                Util.Info(post);
                if (post.Contains("ok"))
                {
                    MongoUtil.set_orders(x.deal_deal_id+"",1);
                }



            }
            else if (x.deal_entry == 0 || x.deal_entry == 2)  //入场。
            {


                string list = "[{";
                list += "\"login\":\"" + x.deal_login + "\",";
                list += "\"deal\":\"" + x.deal_deal_id + "\",";
                list += "\"symbol\":\"" + x.deal_symbol + "\",";
                list += "\"open_price\":\"" + x.price + "\",";
                list += "\"open_time\":\"" + x.time + "\",";
                list += "\"direct\":\"" + x.deal_action + "\",";
                list += "\"ticket\":\"" + x.deal_position_id + "\",";
                list += "\"commission\":\"" + x.commission + "\",";
                list += "\"lots\":\"" + (x.deal_volume / 100) + "\",";
                list += "\"lp_ticket\":\"" + x.deal_lp_ticket + "\",";

                list += "\"comment\":\"\"";
                list += ",\"balance\":\"" + manage.getBalanceBylogin(x.deal_login) + "\"";
                list += "}]";

                string json = "{\"list\":" + list + "}";
                Util.Info(json);
                string post = this.HttpPost(manage.get_crm_host() + "/index.php/index/meta5/inject_open", "value=" + json);
                Util.Info(post);
                if (post.Contains("ok"))
                {
                    MongoUtil.set_orders(x.deal_deal_id + "", 1);
                }

                //出场
            }
            else if (x.deal_entry == 1 || x.deal_entry == 3)
            {

                string list = "[{";
                //list += "\"login\":\"" + deal.Login() + "\",";
                list += "\"deal\":\"" + x.deal_deal_id + "\",";
                //list += "\"symbol\":\"" + deal.Symbol() + "\",";
                list += "\"close_price\":\"" + x.price + "\",";
                list += "\"close_time\":\"" + x.time + "\",";

                list += "\"ticket\":\"" + x.deal_position_id + "\",";
                list += "\"commission\":\"" + x.commission + "\",";
                list += "\"lots\":\"" + (x.deal_volume / 100) + "\",";
                list += "\"lots_closed\":\"" + (x.deal_volume_closed / 100) + "\",";
                list += "\"swap\":\"" + x.storage + "\",";
                list += "\"profit\":\"" + x.profit + "\"";
                list += ",\"balance\":\"" + manage.getBalanceBylogin(x.deal_login) + "\"";


                //list += "\"comment\":\"" + deal.Comment() + "\"";

                list += "}]";

                string json = "{\"list\":" + list + "}";


                Util.Info(json);
                string post = manage.HttpPost(manage.get_crm_host() + "/index.php/index/meta5/inject_close", "value=" + json);
                Util.Info(post);
                if (post.Contains("ok"))
                {
                    MongoUtil.set_orders(x.deal_deal_id + "", 1);
                }
            }

            

            //File.WriteAllText("end_ticket", x.deal_deal_id + "");






        }

        public string HttpPost(string Url, string postDataStr)
        {
            string result = string.Empty;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12; //加上这一句

            try
            {

                //注意提交的编码 这边是需要改变的 这边默认的是Default：系统当前编码
                byte[] postData = Encoding.UTF8.GetBytes(postDataStr);

                // 设置提交的相关参数 
                HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
                Encoding myEncoding = Encoding.UTF8;
                request.Method = "POST";
                request.KeepAlive = false;
                request.AllowAutoRedirect = true;
                request.ContentType = "application/x-www-form-urlencoded";
                request.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727; .NET CLR  3.0.04506.648; .NET CLR 3.5.21022; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)";
                request.ContentLength = postData.Length;
                request.ProtocolVersion = HttpVersion.Version10;

                // 提交请求数据 
                System.IO.Stream outputStream = request.GetRequestStream();
                outputStream.Write(postData, 0, postData.Length);
                outputStream.Close();

                HttpWebResponse response;
                Stream responseStream;
                StreamReader reader;
                string srcString;
                response = request.GetResponse() as HttpWebResponse;
                responseStream = response.GetResponseStream();
                reader = new System.IO.StreamReader(responseStream, Encoding.GetEncoding("UTF-8"));
                srcString = reader.ReadToEnd();
                result = srcString;   //返回值赋值
                reader.Close();
            }
            catch (Exception e)
            {
                Util.Info("fuck...." + e.ToString());
            }
            return result;


        }



    }
}
