﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using AliLib4net;

namespace ManageHolderService
{
    public class Util
    {
        /// <summary>
        /// 加载xml参数
        /// </summary>
        /// <returns></returns>
        static Hashtable args = null;
        public static bool isdebug = false ;
        public static bool service_run = true;
        static AlixLog log = new AlixLog();
        
        public static Hashtable loadXml(bool reload_flag = false)
        {
            

            if (args == null || reload_flag )
            {
                args = new Hashtable();


            }else
            {
                return args;

            }


            XDocument document = XDocument.Load(AppDomain.CurrentDomain.BaseDirectory + "config.xml");
            //获取到XML的根元素进行操作
            XElement root = document.Root;
            args.Add("manage_user", root.Element("manage_user").Value);
            args.Add("manage_psd", root.Element("manage_psd").Value);
            args.Add("manage_host", root.Element("manage_host").Value);
            args.Add("crm_host", root.Element("crm_host").Value);
            args.Add("port", root.Element("port").Value);
            args.Add("name", root.Element("name").Value);

            //------
            args.Add("mongo_ip", root.Element("mongo_ip").Value);
            args.Add("mongo_name", root.Element("mongo_name").Value);
            args.Add("mongo_psd", root.Element("mongo_psd").Value);
            args.Add("mongo_port", root.Element("mongo_port").Value);
            args.Add("mongo_db", root.Element("mongo_db").Value);



            return args;



        }

        public static void Info(string str)
        {
            if (isdebug)
            {
                Console.WriteLine(str);
            }
            else
            {
                log.Info(str);
            }
        }
        public static void Debug(string str)
        {
            if (isdebug)
            {
                Console.WriteLine(str);
            }
            else
            {
                Util.Debug(str);
            }
        }

        public static void Error(string str)
        {
            if (isdebug)
            {
                Console.WriteLine(str);
            }
            else
            {
                Util.Error(str);
            }
        }

        public static string Decode(string data)
        {
            string KEY_64 = "alicrm88";
            string IV_64 = "alicrm88";
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(KEY_64);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(IV_64);
            byte[] byEnc;
            try
            {
                byEnc = Convert.FromBase64String(data);
            }
            catch
            {
                return null;
            }
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream(byEnc);
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateDecryptor(byKey, byIV), CryptoStreamMode.Read);
            StreamReader sr = new StreamReader(cst);
            return sr.ReadToEnd();
        }

        /// <summary>
        /// 加密
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>

        public static string Encode(string data)
        {
            string KEY_64 = "alicrm88";
            string IV_64 = "alicrm88";
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(KEY_64);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(IV_64);
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            int i = cryptoProvider.KeySize;
            MemoryStream ms = new MemoryStream();
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateEncryptor(byKey, byIV), CryptoStreamMode.Write);
            StreamWriter sw = new StreamWriter(cst);
            sw.Write(data);
            sw.Flush();
            cst.FlushFinalBlock();
            sw.Flush();
            return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
        }



    }
}
